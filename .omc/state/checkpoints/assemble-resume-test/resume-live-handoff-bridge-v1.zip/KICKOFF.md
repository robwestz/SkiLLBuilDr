# KICKOFF: resume-live-handoff-bridge-v1

Read this file fully before taking action. Treat it as the source of truth for the package.


## Phase 0 — Preflight Contract (MANDATORY)

Before starting work, complete every block below. Do not edit/write code until 0.6 is signed.
Source: `frameworks/COMPOUND.md` (Gap Scan) + `frameworks/QUALITY_GATE.md`.



### 0.1 Goal restate (your own words, one sentence)

> Original: Resume Live Handoff Bridge v1

Your restatement: _<fill in before starting>_

### 0.2 Skill-scan (against the loaded catalog)

Match the goal against the included skills (see `CLAUDE.md`). Classify the loadout:

- [ ] **Perfect-fit:** every needed capability is covered by an included skill — proceed to 0.4.
- [ ] **Partial:** some gaps exist — list them in 0.3, do not skip.
- [ ] **Miss:** no included skill covers a critical capability — **mandatory** 0.3.

### 0.3 Skill-first fallback (when 0.2 is partial or miss)

**The only sanctioned route out of a gap is to create the missing piece via the skill-development flow.**
Use `/plugin-dev:skill-development` (or the equivalent in your environment) and choose at least one of:

| Type | Create when… |
|---|---|
| Skill | A reusable capability is missing |
| Rule | A constraint must hold across many tasks |
| Agent | A specialized role with its own context is needed |
| Constraint | A hard limit on actions or outputs must be enforced |

Ad-hoc improvisation is **not** acceptable. Either an included skill covers the work, or a new artifact is created and registered before proceeding.

### 0.4 Definition of Done (write before building)

**Tier:** Production — Production-grade. Edge cases handled. Tests cover happy path + critical failures. Maintainable in 3 months.

Required:

- Acceptance criteria (observable behavior, not implementation):
  - _<criterion 1>_
  - _<criterion 2>_
- Verification method (test / smoke / demo / canary):
  - _<method>_
- "Directly usable" check: when a user runs the result, what command or action confirms success?
  - _<command or action>_

### 0.5 Hard gates (what you may NOT do without escalating to operator)

- No destructive ops without explicit confirmation (delete, force-push, drop tables, rm -rf)
- No new external runtime dependencies without flagging (project rule: zero runtime-deps)
- No silent skipping of a chunk's verification step
- No marking phase-complete unless DoD (0.4) is provably met
- No commits without tests green (where tests exist)

### 0.6 Contract signed

By writing your name/agent-id below, you certify 0.1–0.5 are filled in:

_Signed by: <agent or operator>_
_Timestamp: <ISO-8601>_

---

## Goal

Resume Live Handoff Bridge v1

## First Moves

- Clarify the scope and acceptance criteria before implementation.
- Use the selected skills to plan, execute, verify, and document in sequence.

## Included Skills

- `/session-launcher` - | The conductor skill — takes a task or project intent and produces a complete, copy-pasteable startup prompt for a new Claude Code session. Six-step process: INTAKE, SCAN, MATCH, GAP, COMPOSE, DELIVER. The output is a structured prompt block that loads the right skills, reads the right files, queues the right workflows, and defines quality gates — so the new session starts sharp instead of fumbling through discovery. Use when: starting a new Claude Code session for a known task, preparing a handoff prompt for another agent, planning which skills a project needs before building, or auditing whether existing skills cover a task. Trigger on: "launch session for", "prepare a session", "session launcher", "startup prompt for", "what skills do I need for", "plan a session", "handoff prompt", "set up a session for", "which skills should I load".
- `/everything-claude-code:social-graph-ranker` - Weighted social-graph ranking for warm intro discovery, bridge scoring, and network gap analysis across X and LinkedIn. Use when the user wants the reusable graph-ranking engine itself, not the broader outreach or network-maintenance workflow layered on top of it.
- `/everything-claude-code:evm-token-decimals` - Prevent silent decimal mismatch bugs across EVM chains. Covers runtime decimal lookup, chain-aware caching, bridged-token precision drift, and safe normalization for bots, dashboards, and DeFi tools.

## Execution Plan

### Step 1: session-launcher

| The conductor skill — takes a task or project intent and produces a complete, copy-pasteable startup prompt for a new Claude Code session. Six-step process: INTAKE, SCAN, MATCH, GAP, COMPOSE, DELIVER. The output is a structured prompt block that loads the right skills, reads the right files, queues the right workflows, and defines quality gates — so the new session starts sharp instead of fumbling through discovery. Use when: starting a new Claude Code session for a known task, preparing a handoff prompt for another agent, planning which skills a project needs before building, or auditing whether existing skills cover a task. Trigger on: "launch session for", "prepare a session", "session launcher", "startup prompt for", "what skills do I need for", "plan a session", "handoff prompt", "set up a session for", "which skills should I load".

Use `/session-launcher` and follow its contract.


### Step 2: social-graph-ranker

Weighted social-graph ranking for warm intro discovery, bridge scoring, and network gap analysis across X and LinkedIn. Use when the user wants the reusable graph-ranking engine itself, not the broader outreach or network-maintenance workflow layered on top of it.

Use `/everything-claude-code:social-graph-ranker` and follow its contract.


### Step 3: evm-token-decimals

Prevent silent decimal mismatch bugs across EVM chains. Covers runtime decimal lookup, chain-aware caching, bridged-token precision drift, and safe normalization for bots, dashboards, and DeFi tools.

Use `/everything-claude-code:evm-token-decimals` and follow its contract.


## Deliverables

- A coherent implementation of: Resume Live Handoff Bridge v1.
- Clear tests, verification notes, and documented follow-up risks.
- A working implementation plan that can be executed without extra clarification.
- Code, docs, and tests aligned with the stated goal.
- A final handoff that is ready for handoff to Robin or the next agent.

## Success Criteria

- The selected skills are followed in order with explicit progress updates.
- The result is production-grade, offline-first where possible, and documented.
- All critical checks pass and the package is ready for handoff.

## Working Rules

- Stay production-grade throughout the package; do not defer obvious quality work.
- Keep execution offline-first unless an external dependency is explicitly required.
- Verify meaningful changes with tests, checks, or direct inspection before claiming completion.
- Leave the workspace in a state that is ready for handoff.


## Compound Mechanisms (run at every chunk boundary)

Source: `frameworks/COMPOUND.md`. These produce visible output — silent execution does not count.

### Before each chunk: GAP SCAN

```
[GAP SCAN]
INTENT REGROUND: <quote the original goal verbatim>
COMPLETE VERSION: <what a finished, usable result looks like>
PLAN COVERS: <what is planned>
PLAN MISSES: <what a complete version needs that isn't planned>
SHELL CHECK: working component or skeleton/placeholder? If skeleton — STOP, escalate.
DECISION: critical gaps → surface; important → propose; nice-to-have → defer.
```

### After each chunk: COMPOUND REGISTER

```
[COMPOUND]
BUILT:    <what was completed — concrete>
GAINED:   <new capability/pattern/infra>
ENABLES:  <specific upcoming work this enables — must reference real future chunks>
REUSABLE: <functions/patterns/fixtures to carry forward>
LEARNED:  <project-specific insight — not generic>
```

### Every 3rd chunk OR at complexity spike: CONTEXT REFRESH

```
[CONTEXT REFRESH]
PROJECT STATE: <restate primary goal verbatim from above; current chunk; completed+verified; remaining>
DRIFT CHECK: <has direction shifted? am I solving the stated problem?>
COMPOUND STATUS: <which built capabilities am I actively using? underutilized?>
EFFICIENCY OBSERVATION: <given what I now know, is there a better approach for next chunk?>
```

## Eval Loop (run BEFORE Compound Register at every chunk boundary)

Pure adversarial review (find weaknesses) without structured praise causes
agents to drift away from approaches that actually worked. The Eval Loop
captures both — what to fix AND what to keep doing — so the chunk produces
a forward-pointing decision, not just a critique.

Source: validated principle from operator's own memory system
("Record from failure AND success") + extension of
`frameworks/QUALITY_GATE.md`.

**Run this block visibly at chunk end, BEFORE `[COMPOUND]` register.**

```
[EVAL LOOP — chunk <N>]
CRITIQUE (≥2):   what is weak / could fail / would surprise a reviewer
PRAISE   (≥2):   what works genuinely well / should be kept doing
PRESERVE:        which patterns from PRAISE must propagate to next chunks
FIX:             which CRITIQUE items must be fixed before this chunk closes
DEFER:           CRITIQUE items accepted as conscious trade-offs (logged)
DECISION:        proceed | rework | escalate
```

**Rules:**

- CRITIQUE and PRAISE both require ≥2 concrete entries each. Neither side may be empty.
- PRAISE entries must be specific (not "the code is good" — instead
  "the runner.sh `--json` flag emits a parseable result-per-scenario object
  that the integration layer can consume directly").
- PRESERVE binds the next chunk: it carries the named patterns forward.
- DECISION = `rework` blocks `[COMPOUND]` register and re-runs this chunk.
- DECISION = `escalate` surfaces to operator and pauses the chain.

**Live debate substrate (preferred):** `factory/v2-personas/` is bundled in
this package. Run a 3-persona Critic/Appreciator/Decider debate instead of
self-evaluating:

```bash
# 1. Write a chunk-result proposal JSON (signals keyed by criterion id):
cat > /tmp/chunk-eval.proposal.json <<'JSON'
{
  "title": "Chunk N result review",
  "signals": {
    "acceptance_met": "pass",
    "tests_green": "pass",
    "open_risks": "unknown"
  }
}
JSON

# 2. Run the debate (uses the operator-ask config by default):
node factory/v2-personas/debate.mjs \
  --config factory/v2-personas/examples/operator-ask.config.json \
  --proposal /tmp/chunk-eval.proposal.json --json

# 3. Map the artifact: recommendations → DECISION, criteria comments →
#    CRITIQUE/PRAISE, escalations → escalate to operator.
```

If the debate returns `status: "escalated"` or `"no_consensus"`, the
DECISION is automatically `escalate` — no agent override.

**Why this is mandatory, not optional:**

Without PRAISE, agents over-correct on every cycle and lose validated
approaches. Without DECISION, eval becomes a status report instead of a
gate. Without PRESERVE, compound effect leaks: each chunk re-discovers
what the previous chunk already proved.

## Quality Gate (run internally before declaring chunk done)

Source: `frameworks/QUALITY_GATE.md`. **Tier:** Production — Production-grade. Edge cases handled. Tests cover happy path + critical failures. Maintainable in 3 months.

**Process (90% build, 10% review — never invert):**

1. Simulate the strongest competing model as reviewer (Claude → simulate GPT-5; GPT → simulate Opus).
2. Score along the 5 dimensions:
   - **Correctness** — does it match the spec? edge cases?
   - **Architecture** — motivated structure? unnecessary layers?
   - **Cost-efficiency** — same result, cheaper?
   - **Maintainability** — readable in 3 months?
   - **Originality** — genuine fit or copy-paste?
3. Find the 2–3 weakest points.
4. Fix what's fixable; document the rest as conscious trade-offs.
5. Decide: would the simulated reviewer call this **Production**-tier?

**Append at end of chunk delivery:**

```
## Quality Gate
Delivery: <one sentence>
Reviewed against: <Opus 4.7 / GPT-5 / o3> (simulated)
Weaknesses I fixed: <- what → fix → dimension>
Remaining weaknesses (honest): <- specific trade-offs>
Production grade? <Yes/No/Almost — one sentence why>
```

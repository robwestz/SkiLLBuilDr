# resume-live-handoff-bridge-v1

## What this package is for

Resume Live Handoff Bridge v1

## Included files

- `KICKOFF.md` - the first file the agent should read.
- `CLAUDE.md` - the skill list to load into the session.
- `workflows/` - workflow exports for selected chains.
- `README.md` - this summary for humans.

## Selected skills

- session-launcher (`/session-launcher`)
- social-graph-ranker (`/everything-claude-code:social-graph-ranker`)
- evm-token-decimals (`/everything-claude-code:evm-token-decimals`)
